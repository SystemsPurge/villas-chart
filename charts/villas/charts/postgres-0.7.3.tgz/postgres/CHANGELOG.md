# Changelog

## 0.7.3 (2025-10-09)

* [mongodb] feat: add metrics exporter ([#243](https://github.com/CloudPirates-io/helm-charts/pull/243))
